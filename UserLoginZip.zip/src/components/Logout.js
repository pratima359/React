import React, { useEffect } from "react";
import { useDispatch } from "react-redux";
import { logout } from "./actions/authActions";

const Logout = () => {
  const dispatch = useDispatch();
  const navigation = useNavigation();

  useEffect(() => {
    dispatch(logout());

    navigation.navigate("Login");
  }, [dispatch, navigation]);

  return null;
};

export default Logout;
