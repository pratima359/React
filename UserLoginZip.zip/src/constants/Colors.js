export default Colors = {
  primary: "#465bd8",
  input_bg: "3f3f5f7",
  black: "#333",
  white: "#fff",
};
