export const userData = {
  user: [
    {
      id: 1,
      name: "John Doe",
      email: "Joh@gmail.com",
      password: "qwert123",
    },
    {
      id: 2,
      name: "Smith A",
      email: "smitha@gmail.com",
      password: "qwert123",
    },
    {
      id: 3,
      name: "Heather",
      email: "heather@gmail.com",
      password: "qwert123",
    },
  ],
};
