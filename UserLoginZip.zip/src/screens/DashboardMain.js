import React from "react";
import { View, Text, Button } from "react-native";

const HomeScreen = ({ navigation }) => (
  <View>
    <Text>Welcome to the Dashboard!</Text>
    <Button
      title="Go to Profile"
      onPress={() => navigation.navigate("Profile")}
    />
  </View>
);

const ProfileScreen = () => (
  <View>
    <Text>User Profile Screen</Text>
  </View>
);
