import { useRoute } from "@react-navigation/native";
import React, { useEffect, useState } from "react";
import { View, Text, Button, StyleSheet } from "react-native";

const HomeScreen = ({ navigation }) => {
  const values = useRoute();
  const { email, password } = values.params;
  const goToProfile = () => {
    navigation.navigate("Profile", { email, password });
  };

  const [idleTime, setIdleTime] = useState(0);

  useEffect(() => {
    const countTimer = setInterval(() => {
      setIdleTime((prevCount) => {
        return prevCount + 1;
      });
    }, 6000);
    return function cleanup() {
      clearInterval(countTimer);
    };
  });

  return (
    <View
      style={{
        flex: 1,
        alignItems: "center",
        justifyContent: "center",
        backgroundColor: "#0999",
      }}
    >
      <Text style={styles.text}>Welcome to the Home Screen!</Text>
      <Button title="Go to Profile" onPress={goToProfile} />
    </View>
  );
};

export default HomeScreen;

const styles = StyleSheet.create({
  text: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
});
