import {
  StyleSheet,
  TextInput,
  Text,
  View,
  TouchableOpacity,
} from "react-native";
import { useState } from "react";
import { ScrollView } from "react-native-gesture-handler";

const initialErrors = {
  username: "",
  email: "",
};

const ForgotPassword = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
  });
  const [errors, setErrors] = useState(initialErrors);
  console.log(
    "🚀 ~ file: RegisterScreen.js:30 ~ RegistrationForm ~ errors:",
    errors
  );

  ////// ***************************** /////
  const handleRegistration = () => {
    setErrors(initialErrors);

    //Username validation
    const isValidUsername = validateUsername(formData.username);
    const isValidEmail = validateEmail(formData.email);

    setErrors((prev) => ({
      ...prev,
      username: isValidUsername.isValid ? "" : isValidUsername.message,
      email: isValidEmail.isValid ? "" : isValidEmail.message,
    }));

    const valid = isValidUsername.isValid && isValidEmail.isValid;
    if (valid) {
      navigation.navigate("Login", { formData });
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.ScrollView}>
      <View style={styles.container}>
        <Text style={styles.textContainer}>Forgot Password</Text>
        <TextInput
          style={styles.input}
          placeholder="Enter the Username"
          value={formData.username}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, username: text })}
        />
        {errors.username ? (
          <Text style={styles.error}>{errors.username}</Text>
        ) : null}

        <TextInput
          style={styles.input}
          placeholder="Enter the Email"
          value={formData.email}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, email: text })}
        />
        {errors.email ? <Text style={styles.error}>{errors.email}</Text> : null}
        <TouchableOpacity style={styles.button} onPress={handleRegistration}>
          <Text style={styles.buttonText}>Submit</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};
export default ForgotPassword;

const styles = StyleSheet.create({
  textContainer: {
    fontSize: 40,
    color: "#000",
    marginBottom: 20,
    fontWeight: "bold",
  },
  input: {
    width: 350,
    height: 55,
    backgroundColor: "#ffff",
    margin: 10,
    padding: 8,
    color: "grey",
    borderRadius: 14,
    fontSize: 12,
    fontWeight: "500",
  },
  inputField: {
    width: 350,
    height: 100,
    backgroundColor: "#fff",
    margin: 10,
    padding: 8,
    color: "grey",
    borderRadius: 14,
    fontSize: 14,
    fontWeight: "500",
  },
  container: {
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  button: {
    alignItems: "center",
    padding: 10,
    backgroundColor: "#42A5F5",
    marginTop: 16,
    borderRadius: 16,
    width: 240,
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: 24,
  },
  error: {
    color: "red",
    fontSize: 14,
    marginBottom: 8,
    textAlign: "left",
    width: "100%",
  },
  ScrollView: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "pink",
  },
});

const validateUsername = (username) => {
  if (username.length < 3)
    return {
      isValid: false,
      message: "Username must contain at least 3 characters",
    };

  return {
    isValid: true,
  };
};

const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (email.length <= 0)
    return {
      isValid: false,
      message: "Email is required field",
    };

  if (!emailRegex.test(email))
    return {
      isValid: false,
      message: "Email is not valid",
    };

  return {
    isValid: true,
  };
};
