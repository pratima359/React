import {
  StyleSheet,
  TextInput,
  Text,
  View,
  TouchableOpacity,
} from "react-native";
import { useState } from "react";
import { ScrollView } from "react-native-gesture-handler";
import Buttons from "../components/Button";

const initialErrors = {
  username: "",
  email: "",
  dob: "",
  phoneNumber: "",
  password: "",
  confirmPassword: "",
};

const Dashboard = ({ navigation }) => {
  const [formData, setFormData] = useState({
    username: "",
    email: "",
    address: "",
    dateOfBirth: "",
    password: "",
    mobileNumber: "",
    confirmPassword: "",
  });
  const [errors, setErrors] = useState(initialErrors);
  console.log(
    "🚀 ~ file: RegisterScreen.js:30 ~ RegistrationForm ~ errors:",
    errors
  );

  ////// ***************************** /////
  const handleLogOut = () => {
    navigation.navigate("Login");
  };
  const handleRegistration = () => {
    setErrors(initialErrors);

    //Username validation
    const isValidUsername = validateUsername(formData.username);
    const isValidEmail = validateEmail(formData.email);
    const isValidDob = validateDob(formData.dateOfBirth);
    const isValidPhoneNumber = validatePhoneNumber(formData.mobileNumber);
    const isValidPassword = validatePassword(formData.password);
    const isValidPasswordConfirm = validatePasswordConfirm(
      formData.password,
      formData.confirmPassword
    );

    setErrors((prev) => ({
      ...prev,
      username: isValidUsername.isValid ? "" : isValidUsername.message,
      email: isValidEmail.isValid ? "" : isValidEmail.message,
      dob: isValidDob.isValid ? "" : isValidDob.message,
      phoneNumber: isValidPhoneNumber.isValid ? "" : isValidPhoneNumber.message,
      password: isValidPassword.isValid ? "" : isValidPassword.message,
      confirmPassword: isValidPasswordConfirm.isValid
        ? ""
        : isValidPasswordConfirm.message,
    }));

    const valid =
      isValidUsername.isValid &&
      isValidEmail.isValid &&
      isValidDob.isValid &&
      isValidPhoneNumber.isValid &&
      isValidPassword.isValid &&
      isValidPasswordConfirm.isValid;

    if (valid) {
      navigation.navigate("UserHomeScreen", { formData });
    }
  };

  return (
    <ScrollView contentContainerStyle={styles.ScrollView}>
      <View style={styles.container}>
        <Text style={styles.textContainer}>Registration</Text>
        <TextInput
          style={styles.input}
          placeholder="Username"
          value={formData.username}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, username: text })}
        />
        {errors.username ? (
          <Text style={styles.error}>{errors.username}</Text>
        ) : null}

        <TextInput
          style={styles.input}
          placeholder="Email"
          value={formData.email}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, email: text })}
        />
        {errors.email ? <Text style={styles.error}>{errors.email}</Text> : null}
        <TextInput
          style={styles.inputField}
          placeholder="Address"
          multiline={true}
          numberOfLines={5}
          value={formData.address}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, address: text })}
        />
        <TextInput
          style={styles.input}
          placeholder="Date Of Birth"
          value={formData.dateOfBirth}
          placeholderTextColor="grey"
          onChangeText={(text) =>
            setFormData({ ...formData, dateOfBirth: text })
          }
          keyboardType="numeric"
        />
        {errors.dob ? <Text style={styles.error}>{errors.dob}</Text> : null}
        <TextInput
          style={styles.input}
          placeholder="Phone Number"
          value={formData.mobileNumber}
          maxLength={10}
          placeholderTextColor="grey"
          keyboardType="phone-pad"
          onChangeText={(number) =>
            setFormData({ ...formData, mobileNumber: number })
          }
        />
        {errors.phoneNumber ? (
          <Text style={styles.error}>{errors.phoneNumber}</Text>
        ) : null}
        <TextInput
          style={styles.input}
          placeholder="Password"
          value={formData.password}
          secureTextEntry={true}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) => setFormData({ ...formData, password: text })}
        />
        {errors.password ? (
          <Text style={styles.error}>{errors.password}</Text>
        ) : null}
        <TextInput
          style={styles.input}
          placeholder="Confirm Password"
          value={formData.confirmPassword}
          autoCapitalize="none"
          placeholderTextColor="grey"
          onChangeText={(text) =>
            setFormData({ ...formData, confirmPassword: text })
          }
          onSubmitRegistration={() => alert("Registered Successfully")}
        />
        {errors.confirmPassword ? (
          <Text style={styles.error}>{errors.confirmPassword}</Text>
        ) : null}
        <TouchableOpacity style={styles.button} onPress={handleRegistration}>
          <Text style={styles.buttonText}>Register</Text>
        </TouchableOpacity>
        <TouchableOpacity style={styles.button} onPress={handleLogOut}>
          <Text style={styles.buttonText}>LogOut</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};
export default Dashboard;

const styles = StyleSheet.create({
  textContainer: {
    fontSize: 40,
    color: "#000",
    marginBottom: 20,
    fontWeight: "bold",
  },
  input: {
    width: 350,
    height: 55,
    backgroundColor: "#ffff",
    margin: 10,
    padding: 8,
    color: "grey",
    borderRadius: 14,
    fontSize: 12,
    fontWeight: "500",
  },
  inputField: {
    width: 350,
    height: 100,
    backgroundColor: "#fff",
    margin: 10,
    padding: 8,
    color: "grey",
    borderRadius: 14,
    fontSize: 14,
    fontWeight: "500",
  },
  container: {
    flex: 1,
    backgroundColor: "#42A5F5",
    justifyContent: "center",
    alignItems: "center",
    padding: 24,
  },
  button: {
    alignItems: "center",
    padding: 10,
    backgroundColor: "red",
    marginTop: 16,
    borderRadius: 16,
    width: 240,
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: 24,
  },
  error: {
    color: "red",
    fontSize: 14,
    marginBottom: 8,
    textAlign: "left",
    width: "100%",
  },
  ScrollView: {
    alignItems: "center",
    justifyContent: "center",
  },
});

const validateUsername = (username) => {
  if (username.length < 3)
    return {
      isValid: false,
      message: "Username must contain at least 3 characters",
    };

  return {
    isValid: true,
  };
};

const validateEmail = (email) => {
  const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (email.length <= 0)
    return {
      isValid: false,
      message: "Email is required field",
    };

  if (!emailRegex.test(email))
    return {
      isValid: false,
      message: "Email is not valid",
    };

  return {
    isValid: true,
  };
};

const validatePassword = (password) => {
  if (password.length < 6)
    return {
      isValid: false,
      message: "Password must contain at least 6 characters",
    };

  return {
    isValid: true,
  };
};

const validatePasswordConfirm = (password, confirmPassword) => {
  if (!password || !confirmPassword)
    return {
      isValid: false,
      message: "passwords do not match",
    };

  if (password !== confirmPassword)
    return {
      isValid: false,
      message: "passwords do not match",
    };

  return {
    isValid: true,
  };
};

const validatePhoneNumber = (phoneNumber) => {
  const phoneRegex = /^[0-9]{10}$/;

  if (phoneNumber.length <= 0)
    return {
      isValid: false,
      message: "Phone number is required field",
    };

  if (!phoneRegex.test(phoneNumber))
    return {
      isValid: false,
      message: "Date of birth is required field",
    };

  return {
    isValid: true,
  };
};

const validateDob = (dob) => {
  if (dob.length <= 0)
    return {
      isValid: false,
      message: "Date of birth is required field",
    };

  // const dateString = new Date(dob);
  // if (!isNaN(dateString.getTime()))
  //   return {
  //     isValid: false,
  //     message: "Please enter a valid date in YYYY-MM-DD format",
  //   };

  const regex = /^\d{4}-\d{2}-\d{2}$/;
  if (!regex.test(dob))
    return {
      isValid: false,
      message: "Please enter a valid date in YYYY-MM-DD format",
    };

  return {
    isValid: true,
  };
};
