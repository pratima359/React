import React, { useState } from "react";
import { View, Text, StyleSheet, Image } from "react-native";
import { userData } from "../mock/MockedUser";
import { TouchableOpacity } from "react-native-gesture-handler";
import { useRoute } from "@react-navigation/native";

const ProfileScreen = ({ navigation }) => {
  const values = useRoute();
  const { email, password } = values.params;
  const handleRegistration = () => {
    navigation.navigate("Dashboard");
  };
  const data = userData.user;
  const UserDetail = userData.user.filter((value) => {
    value.email === email;
  });
  console.log("userDetail", UserDetail);
  return (
    <View style={styles.container}>
      <Image
        source={require("../assets/images/facebook_icon.png")}
        style={styles.profileImage}
      />

      <Text style={styles.username}>{email}</Text>
      {/* <Button title="User Registration" onPress={Dashboard} /> */}
      <TouchableOpacity style={styles.button} onPress={handleRegistration}>
        <Text style={styles.buttonText}>User Registration</Text>
      </TouchableOpacity>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: "center",
    justifyContent: "center",
    backgroundColor: "pink",
  },
  profileImage: {
    width: 150,
    height: 150,
    borderRadius: 75,
    marginBottom: 20,
  },
  username: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 10,
  },
  bio: {
    fontSize: 16,
    textAlign: "center",
    paddingBottom: 20,
    paddingHorizontal: 20,
  },
  button: {
    alignItems: "center",
    padding: 10,
    backgroundColor: "red",
    marginTop: 16,
    borderRadius: 16,
    width: 240,
  },
  buttonText: {
    color: "#000",
    fontWeight: "bold",
    fontSize: 24,
  },
});

export default ProfileScreen;
