import { createStoreHook } from "react-redux";
import { applyMiddleware, combineReducers } from "redux";
import thunk from "redux-thunk";

const rootReducer = combineReducers({
  auth: authReducer,
});

const store = createStoreHook(rootReducer, applyMiddleware(thunk));

export default store;
