import { LOGIN, LOGOUT, SET_AUTH_DATA } from "./ActionTypes";

export const login = () => ({
  type: LOGIN,
});

export const logout = () => ({
  type: LOGOUT,
});

export const setAuthData = (data) => ({
  type: SET_AUTH_DATA,
  payload: data,
});
