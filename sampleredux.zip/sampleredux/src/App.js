import "./App.css";
import Navbar from "./Navbar";
import Shop from "./Shop";

function App() {
  return (
    <div className="App">
      <Navbar />
      <Shop />
    </div>
  );
}

export default App;
