import React from "react";
import { useDispatch } from "react-redux";
import { depositMoney, withdrawMoney } from "./state/action_creator/Action";

function Shop() {
  // to use action we are using useDispatch()\, here   amountDispatch is function

  const amountDispatch = useDispatch();

  return (
    <div style={{ padding: 30 }}>
      <button
        className="btn btn-success"
        onClick={() => amountDispatch(depositMoney(500))}
      >
        +
      </button>
      Deposit/Withdrew
      <button
        className="btn btn-info"
        onClick={() => amountDispatch(withdrawMoney(100))}
      >
        -
      </button>
    </div>
  );
}

export default Shop;
