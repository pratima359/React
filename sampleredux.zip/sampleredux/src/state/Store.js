// import { createStore } from "react-redux";
import { applyMiddleware } from "redux";
import { legacy_createStore as createStore } from "redux";
import thunk from "redux-thunk";
import reducers from "./reducers/Reducer";

export const store = createStore(reducers, {}, applyMiddleware(thunk));
