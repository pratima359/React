import { combineReducers } from "redux";
import AmountReducers from "./AmountReducer";

const reducers = combineReducers({ amount: AmountReducers });

export default reducers;
