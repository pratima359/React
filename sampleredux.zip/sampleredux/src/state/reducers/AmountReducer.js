const reducer = (state = 0, action) => {
  if (action.type === "Deposit") {
    // state += action.payload;
    return state + action.payload;
  } else if (action.type === "Withdraw") {
    // state += action.payload;
    return state - action.payload;
  } else {
    return state;
  }
};

export default reducer;
